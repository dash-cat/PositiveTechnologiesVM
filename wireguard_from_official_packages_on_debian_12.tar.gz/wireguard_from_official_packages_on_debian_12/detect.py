# Original script by Positive Technologies
# Modified by Maria Zaitseva for 2024 MaxPatrol VM hackathon

import os
import re
from typing import List, Dict, Optional
from template_utils import template_oval_vars

package_fields_need_eq = {
  'name': 'wireguard',
  'maintainer': 'WireGuard maintainers <team@wireguard.com>'
}
version_re = r'([\d.]+)-.+'
oval_vars_template_file = 'oval_vars.xml.j2'
oval_vars_file = 'oval_vars.xml'
soft_name = 'wireguard'

def run_command(command: str) -> str:
  """
  Executes a shell command and returns the output.

  Args:
    command (str): The command to be executed.

  Returns:
    str: The output of the command.
  """
  stream = os.popen(command)
  output = stream.read()
  return output

def parse_packages_list(text: str, regex: str) -> List[Dict[str, str]]:
  """
  Parses the package list using a regular expression.

  Args:
    text (str): The raw package list text.
    regex (str): The regular expression to parse the package list.

  Returns:
    list: A list of dictionaries containing parsed package information.
  """
  r = re.compile(regex)
  result = [i.groupdict() for i in r.finditer(text)]
  return result

def filter_packages(packages: List[Dict[str, str]], fields: Dict[str, str]) -> Optional[Dict[str, str]]:
  """
  Filters packages based on the given fields.

  Args:
    packages (list): A list of dictionaries containing package information.
    fields (dict): A dictionary of fields to filter the packages.

  Returns:
    dict: The first package that matches the filter criteria, or None if no match is found.
  """
  comp_keys = fields.keys()
  for p in packages:
    res = True
    for key in comp_keys:
      if fields.get(key) != p.get(key):
        res = False
        break
    if res:
      return p
  return None

def get_raw_packages() -> str:
  """
  Retrieves raw package information from the system.

  Returns:
    str: Raw package information as a string.
  """
  get_package_cmd = "dpkg-query -f '${Package};;${Status};;${Maintainer};;${Architecture};;${Source};;${Version}\n' -W"
  packages_raw = run_command(get_package_cmd)
  return packages_raw

def get_package(fields: Dict[str, str]) -> Optional[Dict[str, str]]:
  """
  Retrieves package information based on the specified fields.

  Args:
    fields (dict): A dictionary of fields to filter the packages.

  Returns:
    dict: A dictionary containing package information, or None if no package matches the criteria.
  """
  packages_raw = get_raw_packages()
  package_parsing_re = r'(?P<name>.+);;(?P<status>.+);;(?P<maintainer>.+);;(?P<arch>.+);;(?P<source>.*);;(?P<version>.+)'
  packages = parse_packages_list(packages_raw, package_parsing_re)
  package = filter_packages(packages, fields)
  return package

def get_version(package: Dict[str, str], regex: str) -> Optional[str]:
  """
  Extracts the version from the package information using a regular expression.

  Args:
    package (dict): A dictionary containing package information.
    regex (str): The regular expression to extract the version.

  Returns:
    str: The extracted version, or None if not found.
  """
  package_version = package.get('version', '')
  result = re.search(regex, package_version)
  if result:
    return result.groups()[0]
  return None

if __name__ == '__main__':
  """
  Main function to execute the script.
  
  It retrieves the package information, extracts the version, and renders the OVAL variables template.
  """
  context = {
    'name': None,
    'version': None
  }
  package = get_package(package_fields_need_eq)
  if package:
    context['version'] = get_version(package, version_re)

  if context['version']:
    context['name'] = soft_name

  template_oval_vars(oval_vars_template_file, oval_vars_file, context)
