import os
import re
import json
import sys
import requests
import argparse
from jinja2 import FileSystemLoader, Environment

# Set up command line argument parsing
parser = argparse.ArgumentParser(description='Generates OVAL reports.')
parser.add_argument('config_path', type=str, nargs='?', default='./config.json', help='The path to the config.json file')
args = parser.parse_args()

# Load configuration from JSON
with open(args.config_path, 'r') as config_file:
  config = json.load(config_file)

# Extract manufacturer and application name from config.cpe
manufacturer = config['cpe']['manufacturer']
application_name = config['cpe']['app']

cve_api_url = "https://services.nvd.nist.gov/rest/json/cves/2.0"
cves_search_params = {
  "virtualMatchString": f"cpe:2.3:a:{manufacturer}:{application_name}"
}
product_cpe_res = [fr"cpe:2\.3:a:{manufacturer}:{application_name}:([\d.]+|\*):\*:\*:\*:(\*|open_source):"]
context_cpe_res = []
allowed_cve_statuses = ["Analyzed", "Modified"]
print_product_cpe = False
print_context_cpe = False

oval_template_file = "oval.xml.j2"
oval_file = "oval.xml"
oval_product_var_id = 1
oval_version_var_id = 2
oval_affected_family = "unix"
oval_soft_name = application_name

def get_request(cve_api_url, cves_search_params):
  r = requests.get(cve_api_url, params=cves_search_params)
  print('Requested data from %s' % r.url)
  return r.content

def get_cves(cve_api_url, cves_search_params):
  api_r = get_request(cve_api_url, cves_search_params)
  j = json.loads(api_r)
  return j.get('vulnerabilities')

def parse_versions(cpe_match):
  cpe = cpe_match.get('criteria')
  cpe_splited = cpe.split(':')
  ver_start_incl = cpe_match.get('versionStartIncluding')
  ver_end_incl = cpe_match.get('versionEndIncluding')
  ver_start_excl = cpe_match.get('versionStartExcluding')
  ver_end_excl = cpe_match.get('versionEndExcluding')
  ver = cpe_splited[5]
  v = {
    'left_ver': 0,
    'right_ver': 0,
    'left_incl': True,
    'right_incl': True
  }
  if ver != '*':
    v['left_ver'] = ver
    v['right_ver'] = ver
  if ver_start_incl:
    v['left_ver'] = ver_start_incl
  if ver_end_incl:
    v['right_ver'] = ver_end_incl
  if ver_start_excl:
    v['left_ver'] = ver_start_excl
    v['left_incl'] = False
  if ver_end_excl:
    v['right_ver'] = ver_end_excl
    v['right_incl'] = False
  if not v['left_ver'] and not v['right_ver']:
    return None
  return v

def parse_cpe_match(cpe_match, cpe_regexes):
  if not cpe_match.get('vulnerable'):
    return None
  cpe = cpe_match['criteria']
  if print_product_cpe:
    print(cpe)
  cpe_matched = False
  for regex in product_cpe_res:
    r = re.search(regex, cpe)
    if r:
      cpe_matched = True
  if not cpe_matched:
    return None
  versions = parse_versions(cpe_match)
  return versions

def parse_product_item(product_item, product_cpe_res):
  versions = []
  product_operator = product_item.get('operator')
  if product_operator and product_operator != "OR":
    sys.exit('unexpected operator')
  for i in product_item['cpeMatch']:
    version = parse_cpe_match(i, product_cpe_res)
    if version:
      versions.append(version)
  return versions

def check_context(cpe_match):
  cpe = cpe_match.get('criteria')
  if print_context_cpe:
    print(cpe)
  for regex in context_cpe_res:
    r = re.search(regex, cpe)
    if r:
      return True
  return False

def parse_context_item(item):
  operator = item.get('operator')
  if operator and operator != "OR":
    sys.exit('unexpected operator')
  context_found = False
  for i in item.get('cpeMatch', []):
    if check_context(i):
      context_found = True
  return context_found

def check_contexts(contexts):
  context_matched = False
  for context in contexts:
    if context:
      if parse_context_item(context):
        context_matched = True
        break
    else:
      return True
  return context_matched

def parse_conditions(conds):
  versions = []
  for i in conds:
    nodes = i.get('nodes')
    operator = i.get('operator')
    if operator:
      product = nodes[0]
      context = nodes[1]
    else:
      product = nodes
      context = {}
    if type(product) == dict:
      product = [product]
    if type(context) == dict:
      contexts = [context]
    for item in product:
      product_ver = parse_product_item(item, product_cpe_res)
    contexts_matched = check_contexts(contexts)
    if contexts_matched:
      versions = versions + product_ver
  return versions

def get_description(descriptions, lang):
  for i in descriptions:
    if i['lang'] == lang:
      return i['value']
  return ""

def parse_cve(cve):
  r = {}
  status = cve.get('vulnStatus')
  if status not in allowed_cve_statuses:
    return None
  r['id'] = cve.get('id')
  r['description'] = get_description(cve['descriptions'], 'en')
  r['conditions'] = parse_conditions(cve.get('configurations'))
  if not r['conditions']:
    return None
  return r

def parse_vulns(vulns):
  cves = []
  for i in vulns:
    cve = parse_cve(i.get('cve'))
    if cve:
      cves.append(cve)
  return cves

def template_oval_vars(template_file, output_file, context):
  loader = FileSystemLoader("./")
  environment = Environment(loader=loader)
  template = environment.get_template(template_file)
  output = template.render(**context)
  with open(output_file, "w") as f:
    f.write(output)

if __name__ == "__main__":
  print("Getting CVEs...")
  vulns = get_cves(cve_api_url, cves_search_params)
  print("Parsing vulnerabilities...")
  vulns = parse_vulns(vulns)
  context = {
    "soft_name": oval_soft_name,
    "cves": vulns,
    "product_var_id": oval_product_var_id,
    "version_var_id": oval_version_var_id,
    "affected_family": oval_affected_family
  }
  print("Populating template...")
  template_oval_vars(oval_template_file, oval_file, context)
