#!/bin/bash
oscap oval eval --variables ./oval_vars.xml --report report.html ./oval.xml